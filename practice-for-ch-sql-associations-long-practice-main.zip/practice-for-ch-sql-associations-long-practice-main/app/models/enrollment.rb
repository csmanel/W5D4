class Enrollment < ApplicationRecord
end