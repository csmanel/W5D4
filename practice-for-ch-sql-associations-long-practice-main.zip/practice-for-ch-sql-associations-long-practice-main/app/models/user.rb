class User < ApplicationRecord
end