class Course < ApplicationRecord
end